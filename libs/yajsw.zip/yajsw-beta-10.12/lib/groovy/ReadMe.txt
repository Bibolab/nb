The following libraries are loaded when a groovy script is executed.
To add libraries required by groovy scripts create a folder here and add the jar files to the folder.

sendMail.gv requires:
	* mail
	
sendSnmpTrap.gv requires:
	* snmp
	
timeCondition.gv requires:
	* joda