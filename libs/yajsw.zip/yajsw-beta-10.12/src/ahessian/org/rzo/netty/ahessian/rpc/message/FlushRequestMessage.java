package org.rzo.netty.ahessian.rpc.message;

public class FlushRequestMessage
{

}
