/**
 * Encoder, decoder which
 * transform a {@link java.lang.Object} into a byte buffer and
 * vice versa using hessian serialization.
 */
package org.rzo.netty.ahessian.serialization;