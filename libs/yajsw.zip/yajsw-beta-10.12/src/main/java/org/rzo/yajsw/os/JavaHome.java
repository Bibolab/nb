package org.rzo.yajsw.os;

public interface JavaHome
{
	String findJava();

}
