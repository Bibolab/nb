package org.rzo.yajsw.os.posix;

import org.rzo.yajsw.os.Keyboard;

public class PosixKeyboard
{

	public static Keyboard instance()
	{
		// TODO Auto-generated method stub
		return null;
	}

}
