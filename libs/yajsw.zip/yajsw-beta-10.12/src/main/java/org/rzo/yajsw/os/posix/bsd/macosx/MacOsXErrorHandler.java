package org.rzo.yajsw.os.posix.bsd.macosx;

import org.rzo.yajsw.os.posix.bsd.BSDErrorHandler;

public class MacOsXErrorHandler extends BSDErrorHandler
{

}
