package org.rzo.yajsw.os.posix.linux;

import org.apache.commons.configuration.Configuration;
import org.rzo.yajsw.os.posix.PosixJavaHome;

public class LinuxJavaHome extends PosixJavaHome
{

	public LinuxJavaHome(Configuration config)
	{
		super(config);
	}

}
